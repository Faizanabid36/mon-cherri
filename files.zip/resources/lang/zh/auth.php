<?php

return array (
  'failed' => '这些凭据与我们的记录不匹配。',
  'throttle' => '登录尝试次数过多。 请在：seconds秒后重试。',
);
