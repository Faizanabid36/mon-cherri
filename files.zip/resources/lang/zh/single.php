<?php

return array (
  'SECURE PAYMENTS' => 'Payment ho gayi',
);
