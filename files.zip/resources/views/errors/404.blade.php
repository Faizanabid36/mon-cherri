<link href="{{asset('css/style.css')}}" rel="stylesheet" />
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<div class="ps-404 bg--cover">
        <div class="ps-404__content">
            <h1 style="font-family: 'Archivo Narrow', sans-serif;margin: 0px;font-size: 144px;line-height: 1.1;color: #ffffff;letter-spacing: 20px;text-align: center">404</h1>
<h3 style="font-family: Montserrat, sans-serif;line-height: 1.1;color: #ffffff;margin: 0px 0px 25px;font-size: 36px;letter-spacing: 2px;text-align: center">PAGE NOT FOUND</h3>
<p style="font-family: Montserrat, sans-serif;font-weight: normal;margin: 0px 0px 30px;font-size: 24px;line-height: 1.5em;color: #999999;text-align: center">The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.</p>
            <a class="ps-btn" href="{{url('/')}}">Back to home<i class="ps-icon-next"></i></a>
        </div>
    </div>
</body>
</html>
