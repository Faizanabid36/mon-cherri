
<?php 
  $cartcontent = Cart::content();
?>