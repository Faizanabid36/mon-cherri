@extends('layouts.master')
@section('title', 'Search')
@section('content')

@endsection