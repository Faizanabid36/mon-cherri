@extends('layouts.master')
@section('title', 'Blog')
@section('content')
  {{ Breadcrumbs::render('blog') }}
@endsection