@extends('layouts.master')
@section('title', 'Help')

@section('content')
  {{ Breadcrumbs::render('help') }}
@endsection